# Android Affirmations Sample Project
