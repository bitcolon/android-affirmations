package com.bitcolon.affirmations.model

data class Affirmation(
    val stringResourceId: Int
)